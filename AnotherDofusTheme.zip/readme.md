> **Disclaimer :** This theme is inspired from N0t_Lilithem. I am NOT the creator of the project. [Here](https://gitlab.com/N0t/dofus-theme/-/raw/main/Lilitheme.json) is the original.

Another theme for Dofus 2

